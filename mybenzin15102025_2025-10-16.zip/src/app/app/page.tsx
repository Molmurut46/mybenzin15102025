import { AppPageClient } from "@/components/app/AppPageClient"

export default function AppPage() {
  return <AppPageClient />
}