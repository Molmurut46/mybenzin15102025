ALTER TABLE `user_profiles` ADD `vehicle_year` integer;--> statement-breakpoint
ALTER TABLE `user_profiles` ADD `vin_number` text;--> statement-breakpoint
ALTER TABLE `user_profiles` ADD `license_plate` text;--> statement-breakpoint
ALTER TABLE `weekly_schedules` ADD `highway` integer DEFAULT false;--> statement-breakpoint
ALTER TABLE `weekly_schedules` ADD `city` integer DEFAULT false;--> statement-breakpoint
ALTER TABLE `weekly_schedules` ADD `poor_roads` integer DEFAULT false;