ALTER TABLE `user_profiles` ADD `fuel_consumption_92` real;--> statement-breakpoint
ALTER TABLE `user_profiles` ADD `fuel_consumption_95` real;