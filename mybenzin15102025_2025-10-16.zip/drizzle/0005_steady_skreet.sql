ALTER TABLE `report_templates` ADD `summary_alignment` text DEFAULT 'right';--> statement-breakpoint
ALTER TABLE `report_templates` ADD `date_alignment` text DEFAULT 'left';--> statement-breakpoint
ALTER TABLE `report_templates` ADD `signature_alignment` text DEFAULT 'right';